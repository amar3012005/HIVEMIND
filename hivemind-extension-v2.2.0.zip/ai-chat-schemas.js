/**
 * AI Chat Platform Schemas
 * 
 * Defines platform-specific selectors and prompts for auto-capturing
 * AI chat sessions from Claude, ChatGPT, Gemini, etc.
 */

const AI_CHAT_SCHEMAS = {
  claude: {
    urlPattern: /claude\.ai/,
    name: 'Claude',
    color: '#CC785C',
    selectors: {
      input: 'div[contenteditable="true"][data-placeholder]',
      inputFallback: 'div.ProseMirror[contenteditable="true"]',
      submit: 'button[aria-label="Send Message"]',
      submitFallback: 'button svg[data-icon="send"]',
      messages: 'div[data-testid="user-message"], div[data-testid="assistant-message"]',
      lastMessage: 'div[data-testid="assistant-message"]:last-of-type',
      userMessages: 'div[data-testid="user-message"]',
      assistantMessages: 'div[data-testid="assistant-message"]',
      thinkingIndicator: 'div[data-testid="thinking-indicator"]',
    },
    summaryPrompt: `Please provide a concise summary of our entire conversation:

1. Main topics discussed
2. Key decisions or conclusions  
3. Code/solutions provided (if any)
4. Action items or next steps

Format as clear bullet points. Be thorough but concise.`,
    waitForResponse: {
      timeout: 45000,
      checkInterval: 800,
      thinkingIndicator: 'div[data-testid="thinking-indicator"]',
    },
    extraction: {
      chatHistoryScript: `
        const messages = [];
        document.querySelectorAll('div[data-testid="user-message"], div[data-testid="assistant-message"]').forEach(el => {
          const role = el.dataset.testid === 'user-message' ? 'user' : 'assistant';
          const content = el.innerText.trim();
          if (content) messages.push({ role, content });
        });
        return messages;
      `,
      lastMessageScript: `
        const lastMsg = document.querySelector('div[data-testid="assistant-message"]:last-of-type');
        return lastMsg ? lastMsg.innerText.trim() : null;
      `,
    },
  },

  chatgpt: {
    urlPattern: /chatgpt\.com|chat\.openai\.com/,
    name: 'ChatGPT',
    color: '#10A37F',
    selectors: {
      input: '#prompt-textarea',
      inputFallback: 'textarea[data-id="root"]',
      submit: 'button[data-testid="send-button"]',
      submitFallback: 'button[aria-label="Send prompt"]',
      messages: 'div[data-message-author-role]',
      lastMessage: 'div[data-message-author-role="assistant"]:last-of-type',
      userMessages: 'div[data-message-author-role="user"]',
      assistantMessages: 'div[data-message-author-role="assistant"]',
      thinkingIndicator: 'div.result-streaming',
    },
    summaryPrompt: `Summarize our conversation with:

- Key topics covered
- Important decisions made
- Code snippets or solutions discussed
- Open questions or next steps

Use bullet points and be comprehensive.`,
    waitForResponse: {
      timeout: 45000,
      checkInterval: 800,
      thinkingIndicator: 'div.result-streaming',
    },
    extraction: {
      chatHistoryScript: `
        const messages = [];
        document.querySelectorAll('div[data-message-author-role]').forEach(el => {
          const role = el.dataset.messageAuthorRole;
          const content = el.innerText.trim();
          if (content && role) messages.push({ role, content });
        });
        return messages;
      `,
      lastMessageScript: `
        const lastMsg = document.querySelector('div[data-message-author-role="assistant"]:last-of-type');
        return lastMsg ? lastMsg.innerText.trim() : null;
      `,
    },
  },

  gemini: {
    urlPattern: /gemini\.google\.com/,
    name: 'Gemini',
    color: '#4285F4',
    selectors: {
      input: 'rich-textarea[aria-label*="prompt"]',
      inputFallback: 'div[contenteditable="true"][aria-label*="prompt"]',
      submit: 'button[aria-label*="Send message"]',
      submitFallback: 'button mat-icon[aria-label="Send"]',
      messages: 'message-content',
      lastMessage: 'message-content[data-is-model-turn="true"]:last-of-type',
      userMessages: 'message-content[data-is-model-turn="false"]',
      assistantMessages: 'message-content[data-is-model-turn="true"]',
      thinkingIndicator: 'mat-spinner',
    },
    summaryPrompt: `Please summarize our conversation covering:

1. Main topics discussed
2. Key insights or conclusions
3. Code examples (if applicable)
4. Recommended next steps

Format clearly with bullet points.`,
    waitForResponse: {
      timeout: 45000,
      checkInterval: 800,
      thinkingIndicator: 'mat-spinner',
    },
    extraction: {
      chatHistoryScript: `
        const messages = [];
        document.querySelectorAll('message-content').forEach(el => {
          const role = el.dataset.isModelTurn === 'true' ? 'assistant' : 'user';
          const content = el.innerText.trim();
          if (content) messages.push({ role, content });
        });
        return messages;
      `,
      lastMessageScript: `
        const lastMsg = document.querySelector('message-content[data-is-model-turn="true"]:last-of-type');
        return lastMsg ? lastMsg.innerText.trim() : null;
      `,
    },
  },

  perplexity: {
    urlPattern: /perplexity\.ai/,
    name: 'Perplexity',
    color: '#1C1C1C',
    selectors: {
      input: 'textarea[placeholder*="Ask"]',
      inputFallback: 'textarea',
      submit: 'button[aria-label="Submit"]',
      submitFallback: 'button svg[data-icon="arrow-up"]',
      messages: 'div[class*="MessageContainer"]',
      lastMessage: 'div[class*="MessageContainer"]:last-of-type',
      userMessages: 'div[class*="UserMessage"]',
      assistantMessages: 'div[class*="AssistantMessage"]',
      thinkingIndicator: 'div[class*="LoadingDots"]',
    },
    summaryPrompt: `Summarize our conversation:

- Topics explored
- Key findings
- Sources cited
- Follow-up questions

Be concise and use bullet points.`,
    waitForResponse: {
      timeout: 45000,
      checkInterval: 800,
      thinkingIndicator: 'div[class*="LoadingDots"]',
    },
    extraction: {
      chatHistoryScript: `
        const messages = [];
        document.querySelectorAll('div[class*="MessageContainer"]').forEach(el => {
          const isUser = el.querySelector('div[class*="UserMessage"]');
          const role = isUser ? 'user' : 'assistant';
          const content = el.innerText.trim();
          if (content) messages.push({ role, content });
        });
        return messages;
      `,
      lastMessageScript: `
        const lastMsg = document.querySelector('div[class*="MessageContainer"]:last-of-type');
        return lastMsg ? lastMsg.innerText.trim() : null;
      `,
    },
  },
};

/**
 * Detect AI chat platform from URL
 */
function detectAIChatPlatform(url) {
  if (!url) return null;
  
  for (const [key, schema] of Object.entries(AI_CHAT_SCHEMAS)) {
    if (schema.urlPattern.test(url)) {
      return { id: key, ...schema };
    }
  }
  
  return null;
}

/**
 * Get summary prompt for platform
 */
function getSummaryPrompt(platformId) {
  return AI_CHAT_SCHEMAS[platformId]?.summaryPrompt || null;
}

/**
 * Check if URL is an AI chat platform
 */
function isAIChatPlatform(url) {
  return detectAIChatPlatform(url) !== null;
}
